package com.infygo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyzgoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
