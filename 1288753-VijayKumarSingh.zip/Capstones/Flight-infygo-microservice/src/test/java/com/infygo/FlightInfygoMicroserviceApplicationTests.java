package com.infygo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightInfygoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
